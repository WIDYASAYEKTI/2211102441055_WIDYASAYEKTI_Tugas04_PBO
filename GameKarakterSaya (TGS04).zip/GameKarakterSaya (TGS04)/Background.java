import greenfoot.*;

public class Background extends World {
    private int currentLevel = 1;
    private boolean gameEnded = false; // Menambahkan variabel untuk melacak status permainan

    public Background() {
        super(800, 399, 1);
        GreenfootImage background = new GreenfootImage("Background.jpg");
        setBackground(background);
        prepare();
    }

    public void act() {
        if (!gameEnded) { // Hanya lanjutkan jika permainan belum berakhir
            if (getObjects(Buah.class).isEmpty()) {
                if (currentLevel < 3) {
                    currentLevel++;
                    Greenfoot.delay(100);
                    nextLevel();
                } else {
                    showText("You Win!", getWidth() / 2, getHeight() / 2);
                    gameEnded = true; // Menandai bahwa permainan telah berakhir
                }
            }
        } else {
            if (getObjects(Harimau.class).isEmpty()) {
                showText("Game Over", getWidth() / 2, getHeight() / 2);
            }
        }
    }

    public void prepare() {
        addObject(new Kancil(), getWidth() / 2, getHeight() / 2);
        addObject(new Buah("Anggur"), Greenfoot.getRandomNumber(getWidth()), Greenfoot.getRandomNumber(getHeight()));
        addObject(new Buah("Apel"), Greenfoot.getRandomNumber(getWidth()), Greenfoot.getRandomNumber(getHeight()));
        addObject(new Buah("Ceri"), Greenfoot.getRandomNumber(getWidth()), Greenfoot.getRandomNumber(getHeight()));
        addObject(new Buah("Mangga"), Greenfoot.getRandomNumber(getWidth()), Greenfoot.getRandomNumber(getHeight()));
        addObject(new Buah("Manggis"), Greenfoot.getRandomNumber(getWidth()), Greenfoot.getRandomNumber(getHeight()));
        addObject(new Buah("Pisang"), Greenfoot.getRandomNumber(getWidth()), Greenfoot.getRandomNumber(getHeight()));
        addObject(new Harimau(), 626, 206);
    }

    public void nextLevel() {
        removeObjects(getObjects(Buah.class));
        prepare();
    }
}
