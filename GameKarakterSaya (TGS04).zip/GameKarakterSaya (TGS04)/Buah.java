import greenfoot.*;

public class Buah extends Actor {
    private String jenisBuah;
    private int scoreValue;

    public Buah(String jenisBuah) {
        this.jenisBuah = jenisBuah;

        if (jenisBuah.equals("Anggur")) {
            setImage("anggur.png");
            scoreValue = 5;
        } else if (jenisBuah.equals("Apel")) {
            setImage("apel.png");
            scoreValue = 3;
        } else if (jenisBuah.equals("Ceri")) {
            setImage("ceri.png");
            scoreValue = 4;
        } else if (jenisBuah.equals("Mangga")) {
            setImage("mangga.png");
            scoreValue = 6;
        } else if (jenisBuah.equals("Manggis")) {
            setImage("manggis.png");
            scoreValue = 7;
        } else if (jenisBuah.equals("Pisang")) {
            setImage("pisang.png");
            scoreValue = 2;
        }
    }

    public void act() {
        checkCollection();
    }

    private void checkCollection() {
        if (isTouching(Kancil.class)) {
            Kancil kancil = (Kancil) getOneIntersectingObject(Kancil.class);
            kancil.collectFruit(scoreValue);
            Greenfoot.playSound("SuaraMakanBuah.wav"); // Tambahkan efek suara ketika Buah dimakan
            getWorld().removeObject(this);
        }
    }
}
