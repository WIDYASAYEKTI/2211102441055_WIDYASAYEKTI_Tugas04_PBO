import greenfoot.*;

public class Harimau extends Actor {
    public Harimau() {
        setImage("harimau.png");
    }

    public void act() {
        if (!isGameOver()) { // Periksa apakah permainan sudah berakhir
            chaseKancil();
            checkEdge();
        }
    }

    public void chaseKancil() {
        Kancil kancil = (Kancil) getWorld().getObjects(Kancil.class).get(0);

        if (kancil != null) {
            int targetX = kancil.getX();
            int targetY = kancil.getY();

            int deltaX = targetX - getX();
            int deltaY = targetY - getY();

            double angle = Math.toDegrees(Math.atan2(deltaY, deltaX));
            int speed = 2; // Kecepatan Harimau

            int dx = (int) (speed * Math.cos(Math.toRadians(angle)));
            int dy = (int) (speed * Math.sin(Math.toRadians(angle)));
            setLocation(getX() + dx, getY() + dy);
        }
    }

    public void checkEdge() {
        if (isAtEdge()) {
            getWorld().removeObject(this);
        }
    }

    public boolean isGameOver() {
        Kancil kancil = (Kancil) getWorld().getObjects(Kancil.class).get(0);
        if (kancil != null && getIntersectingObjects(Kancil.class).size() > 0) {
            getWorld().showText("Game Over", getWorld().getWidth() / 2, getWorld().getHeight() / 2);
            Greenfoot.playSound("SuaraHarimau.wav"); // Memainkan efek suara ketika harimau berhasil menangkap kancil
            Greenfoot.stop();
            return true;
        }
        return false;
    }
}
