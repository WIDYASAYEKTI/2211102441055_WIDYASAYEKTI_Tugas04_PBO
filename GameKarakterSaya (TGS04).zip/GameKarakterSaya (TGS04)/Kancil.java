import greenfoot.*;

public class Kancil extends Actor {
    private int score = 0;

    public Kancil() {
        setImage("kancil.png");
    }

    public void act() {
        checkForCollision();
        updateScore();
        moveWithArrowKeys(); // Panggil metode untuk menggerakkan aktor dengan tombol panah
    }

    public void checkForCollision() {
        Actor object = getOneIntersectingObject(Buah.class);
        if (object != null) {
            collectFruit(50); // Ganti 50 dengan nilai yang sesuai
            getWorld().removeObject(object);
        }
    }

    public void collectFruit(int scoreValue) {
        score += scoreValue;
    }

    public void updateScore() {
        getWorld().showText("Score: " + score, 60, 20);
    }

    public void moveWithArrowKeys() {
        if (Greenfoot.isKeyDown("left")) {
            setLocation(getX() - 2, getY());
        }
        if (Greenfoot.isKeyDown("right")) {
            setLocation(getX() + 2, getY());
        }
        if (Greenfoot.isKeyDown("up")) {
            setLocation(getX(), getY() - 2);
        }
        if (Greenfoot.isKeyDown("down")) {
            setLocation(getX(), getY() + 2);
        }
    }
}